// Scenario 2.1 – Library Members
// Run: mongosh "mongodb://127.0.0.1:27017" "Scenario_2.1_Library_Members/task_2_1_library.js"

const libraryDB = db.getSiblingDB("library");
print("\n========== SCENARIO 2.1 – LIBRARY MEMBERS ==========");

// Task 1: Create database/collection and insert four members.
print("\n--- TASK 1: Create library database and insert four members ---");
libraryDB.members.drop();
const insertResult = libraryDB.members.insertMany([
  {
    name: "Ravi",
    address: { city: "Chennai", pin: "600001" },
    borrowed: ["Python Basics", "MongoDB Guide"],
    fee: 0
  },
  {
    name: "Kumar",
    address: { city: "Chennai", pin: "600028" },
    borrowed: [],
    fee: 0
  },
  {
    name: "Sita",
    address: { city: "Bengaluru", pin: "560001" },
    borrowed: ["MongoDB Guide"],
    fee: 50
  },
  {
    name: "Lakshmi",
    address: { city: "Hyderabad", pin: "500001" },
    borrowed: ["Python Basics"],
    fee: 120
  }
]);
printjson(insertResult);
print("\nDatabases:");
printjson(libraryDB.adminCommand({ listDatabases: 1 }).databases.map(x => x.name));
print("Collections in library:");
printjson(libraryDB.getCollectionNames());

// Task 2: Dot notation query on embedded address.
print("\n--- TASK 2: Find members who live in Chennai (dot notation) ---");
libraryDB.members.find(
  { "address.city": "Chennai" },
  { _id: 0, name: 1, address: 1 }
).forEach(printjson);

// Task 3: Find members who borrowed MongoDB Guide.
print("\n--- TASK 3: Find members who borrowed MongoDB Guide ---");
libraryDB.members.find(
  { borrowed: "MongoDB Guide" },
  { _id: 0, name: 1, borrowed: 1 }
).forEach(printjson);

// Task 4: $all requires both book titles in the array.
print("\n--- TASK 4: Find members who borrowed both books using $all ---");
libraryDB.members.find(
  { borrowed: { $all: ["Python Basics", "MongoDB Guide"] } },
  { _id: 0, name: 1 }
).forEach(printjson);

// Task 5: $size finds an array containing zero elements.
print("\n--- TASK 5: Find members with no borrowed books using $size ---");
libraryDB.members.find(
  { borrowed: { $size: 0 } },
  { _id: 0, name: 1 }
).forEach(printjson);

// Task 6: Update Sita's embedded city using dot notation and $set.
print("\n--- TASK 6: Change Sita's city to Chennai ---");
printjson(libraryDB.members.updateOne(
  { name: "Sita" },
  { $set: { "address.city": "Chennai" } }
));
print("Sita after update:");
libraryDB.members.find(
  { name: "Sita" },
  { _id: 0, name: 1, address: 1 }
).forEach(printjson);

// Task 7: Count positive fees, then drop the collection.
print("\n--- TASK 7: Count members with fee greater than zero ---");
print("Members owing a fee:");
print(libraryDB.members.countDocuments({ fee: { $gt: 0 } }));
print("Expected count: 2 (Sita and Lakshmi)");
print("Dropping members collection:");
print(libraryDB.members.drop());
print("========== END SCENARIO 2.1 ==========\n");
