# MongoDB End Term 2 – Set B2 Project

This project implements the tasks that are fully specified in the supplied PDF:
- Scenario 2.1 – Library Members (embedded documents, arrays, dot notation)
- Scenario 2.2 – Sales Report (aggregation pipeline)

**Important source limitation:** The uploaded PDF mentions Scenarios 2.3 and 2.4 in its introduction, but the supplied 3-page document contains requirements and expected output only for Scenarios 2.1 and 2.2. I have not invented tasks for 2.3 or 2.4. Share the remaining pages if you need those included.

## Requirements
- MongoDB Server running locally (or a MongoDB Atlas connection)
- MongoDB Shell (`mongosh`) installed
- A terminal / command prompt

Check installation:
```bash
mongosh --version
```

If using a local MongoDB server, start it first. On Windows, open MongoDB Compass or start the MongoDB service, then open Command Prompt. On macOS/Linux, start the MongoDB service using the method for your installation.

## Run task-wise

Run each script from the project folder:

### Scenario 2.1 – Library Members
```bash
mongosh "mongodb://127.0.0.1:27017" "Scenario_2.1_Library_Members/task_2_1_library.js"
```
The script prints numbered task headings and results. It creates `library.members`, performs all requested queries and update, counts members with fees greater than zero, and finally drops the `members` collection as required by the PDF.

### Scenario 2.2 – Sales Report
```bash
mongosh "mongodb://127.0.0.1:27017" "Scenario_2.2_Sales_Report/task_2_2_sales.js"
```
The script creates `sales.orders` and runs all six requested operations. It leaves the collection in place so you can inspect it again.

If `mongosh` is already open interactively, you can run:
```javascript
load("Scenario_2.1_Library_Members/task_2_1_library.js")
load("Scenario_2.2_Sales_Report/task_2_2_sales.js")
```

## How to get output and take screenshots
1. Open Command Prompt / Terminal in the extracted project folder.
2. Run one scenario command from above.
3. Maximize the terminal and increase the font size so the output is readable.
4. Wait until the script finishes. The numbered headings identify each task.
5. Take screenshots of the terminal output:
   - Windows: `Win + Shift + S`
   - macOS: `Shift + Command + 4`
   - Linux: use your desktop screenshot shortcut/tool
6. Save screenshots in your practical file under the matching scenario and task number.
7. For a clean screenshot, capture each task section separately rather than shrinking the terminal to fit everything.

## Expected result checkpoints

### Scenario 2.1
- Task 1: four members inserted; database and collection listed.
- Task 2: Ravi and Kumar are returned for Chennai before the update.
- Task 3: Ravi and Sita borrowed `MongoDB Guide`.
- Task 4: only Ravi has both `Python Basics` and `MongoDB Guide`.
- Task 5: Kumar has an empty borrowed array.
- Task 6: Sita's city is updated to Chennai.
- Task 7: count is `2` (Sita and Lakshmi); collection drop returns `true`.

Note: The script displays the fee count before dropping the collection. After Task 7, `library.members` no longer exists, as requested.

### Scenario 2.2
- Task 1: six orders inserted.
- Task 2: Electronics orders are Laptop, Mouse and Headphones (order IDs 1, 2, 5).
- Task 3: line totals are 55000, 1000, 400, 200, 1500 and 7000.
- Task 4: quantities are Electronics 4, Stationery 30, Furniture 2.
- Task 5: revenues are Electronics 57500, Furniture 7000, Stationery 600; average unit prices are 19000, 3500 and 25 respectively.
- Task 6: top two customers are Arun (55400) and Karthik (7000).

## Troubleshooting
- `mongosh is not recognized`: install MongoDB Shell and add its install folder to PATH, or run it using its full executable path.
- `ECONNREFUSED`: MongoDB Server is not running, or your connection URI/port is wrong.
- Atlas: replace `mongodb://127.0.0.1:27017` with your Atlas connection string (keep it quoted). Ensure your IP is allowed in Atlas Network Access and your database user has permissions.
- Re-running Scenario 2.1 is safe: it drops and recreates the `members` collection at the beginning, then drops it again at the end.
- Re-running Scenario 2.2: it drops and recreates `orders` at the beginning to avoid duplicate seed records.

## Source alignment
Task names and requirements follow the uploaded **MongoDB End Term 2 Set_B2.pdf**, pages 1–3. The expected output checkpoints are based on the PDF. ObjectIds and database storage sizes will naturally differ on your machine.
