// Scenario 2.2 – Sales Report
// Run: mongosh "mongodb://127.0.0.1:27017" "Scenario_2.2_Sales_Report/task_2_2_sales.js"

const salesDB = db.getSiblingDB("sales");
print("\n========== SCENARIO 2.2 – SALES REPORT ==========");

// Task 1: Insert six orders. Unit prices and quantities reproduce the PDF's
// expected line totals, category totals, revenues and customer spending.
print("\n--- TASK 1: Insert six orders ---");
salesDB.orders.drop();
const insertResult = salesDB.orders.insertMany([
  { orderId: 1, customer: "Arun",    product: "Laptop",     category: "Electronics", qty: 1,  price: 55000 },
  { orderId: 2, customer: "Divya",   product: "Mouse",      category: "Electronics", qty: 2,  price: 500 },
  { orderId: 3, customer: "Arun",    product: "Notebook",   category: "Stationery",  qty: 10, price: 40 },
  { orderId: 4, customer: "Meena",   product: "Pen",        category: "Stationery",  qty: 20, price: 10 },
  { orderId: 5, customer: "Divya",   product: "Headphones", category: "Electronics", qty: 1,  price: 1500 },
  { orderId: 6, customer: "Karthik", product: "Chair",      category: "Furniture",   qty: 2,  price: 3500 }
]);
printjson(insertResult);

// Task 2: Filter Electronics and project orderId/product.
print("\n--- TASK 2: Electronics orders using $match and $project ---");
salesDB.orders.aggregate([
  { $match: { category: "Electronics" } },
  { $project: { _id: 0, orderId: 1, product: 1 } },
  { $sort: { orderId: 1 } }
]).forEach(printjson);

// Task 3: Calculate qty × price for each order line.
print("\n--- TASK 3: Line total using $multiply ---");
salesDB.orders.aggregate([
  {
    $project: {
      _id: 0,
      orderId: 1,
      customer: 1,
      lineTotal: { $multiply: ["$qty", "$price"] }
    }
  },
  { $sort: { orderId: 1 } }
]).forEach(printjson);

// Task 4: Total quantity sold in each category.
print("\n--- TASK 4: Total quantity per category using $group and $sum ---");
salesDB.orders.aggregate([
  {
    $group: {
      _id: "$category",
      totalQty: { $sum: "$qty" }
    }
  },
  { $sort: { _id: 1 } }
]).forEach(printjson);

// Task 5: Revenue and average unit price per category, highest revenue first.
print("\n--- TASK 5: Category revenue and average price ---");
salesDB.orders.aggregate([
  {
    $group: {
      _id: "$category",
      revenue: { $sum: { $multiply: ["$qty", "$price"] } },
      avgPrice: { $avg: "$price" }
    }
  },
  { $sort: { revenue: -1 } }
]).forEach(printjson);

// Task 6: Top two customers by total spend.
print("\n--- TASK 6: Top two customers by total spend ---");
salesDB.orders.aggregate([
  {
    $group: {
      _id: "$customer",
      spent: { $sum: { $multiply: ["$qty", "$price"] } }
    }
  },
  { $sort: { spent: -1 } },
  { $limit: 2 }
]).forEach(printjson);

print("========== END SCENARIO 2.2 ==========\n");
